﻿namespace PricingCalculator.Factories
{
    using System;
    using Domain;

    public class ProductFactory
    {
        public Product CreateProduct(string productName)
        {
            switch (productName.ToLower())
            {
                case "apples":
                    return new Product
                    {
                        Id = 1,
                        ProductName = "Apples",
                        UnitPrice = 1.00m
                    };
                case "beans":
                    return new Product
                    {
                        Id = 2,
                        ProductName = "Beans",
                        UnitPrice = 0.65m
                    };
                case "bread":
                    return new Product
                    {
                        Id = 3,
                        ProductName = "Bread",
                        UnitPrice = 0.80m
                    };
                case "milk":
                    return new Product
                    {
                        Id = 4,
                        ProductName = "Milk",
                        UnitPrice = 1.30m
                    };
                default:
                    throw new NotSupportedException($"Unrecognized product name : {productName.ToLower()}");
            }
        }
    }
}
