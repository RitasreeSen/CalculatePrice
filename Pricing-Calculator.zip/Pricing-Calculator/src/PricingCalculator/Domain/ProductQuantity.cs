﻿namespace PricingCalculator.Domain
{
    public class ProductQuantity
    {
        public Product Product { get; set; }

        public int Quantity { get; set; }
    }
}
