﻿namespace PricingCalculator.Domain
{
    public class DiscountedProduct
    {
        public int Id { get; set; }
        public string ProductName { get; set; }       
    }
}
