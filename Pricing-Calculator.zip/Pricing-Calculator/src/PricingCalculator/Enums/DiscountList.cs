﻿namespace PricingCalculator.Enums
{
    public enum DiscountList
    {
        None,
        PercentageDiscount,
        HalfPrice
    }
}
